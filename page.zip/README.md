GRE Benchmarking Present Page
=========================

Jekyll theme based on [Grayscale bootstrap theme ](http://ironsummitmedia.github.io/startbootstrap-grayscale/)

## Demo
View this page [here](https://rzwen.github.io/)

## Screenshot
## Homepage
![screenshot](https://github.com/rzwen/rzwen.github.io/blob/master/screenshot/homepage.png)

## HeatMap 
![screenshot](https://github.com/rzwen/rzwen.github.io/blob/master/screenshot/heatmap.png)

## Leaderboard
![screenshot](https://github.com/rzwen/rzwen.github.io/blob/master/screenshot/LeaderBoard.png)

=========
For more details, read the [documentation](http://jekyllrb.com/)
